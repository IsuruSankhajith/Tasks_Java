#01----------------------------------------------------------
#num= 3
#if num > 0:
#    print('true')
#print('false')

#02-----------------------------------------------------------
#num = 3
#if num >= 5:
#    print('True')
#else:
#    print('False')

#03-----------------------------------------------------------
#num = 3
#if num > 0:
#    print('true')
#elif num == 0:
#   print('Fuck')
#else:
#    print('False')
#04----------------------------------------------------------
#num=float(input('numbers :'))
#if num > 0:
#        print('fuck')
#    else:
#         print('good Fuck')
#else:
#    print('bad Fuck')
#01----------------------------------------------------------
#x=input('marks :')

#if int(x) >= 50:
#    print('passses')
#else:
#    print('Fail')

#01----------------------------------------------------------
marksList = [100,200,300,400]
#print(marksList[1])
#marksList[1] = 50
#print(marksList[1])
#print(marksList[-1])

#text = 'isuru'

#print(text[1:2])
#print(marksList[1:3])
#01----------------------------------------------------------
myList = [1,42,-9000,3.14]
#print(myList)

#len(myList)

#myList.append(42)

#myList.count(42)

#myList.insert(2,18)

#myList.remove(42)

#del myList[1]

#myList.sort()
#01----------------------------------------------------------
#text = ['c,o,n,c,a,t,e,n,t,i,o,n']
#print(text[3])

#01----------------------------------------------------------
#marks = [10,20,30,40]
#newmarks = []
#count = 0
#while count <4:
#    marks[count] = marks[count] - 5 
#    print(marks[count])
#    count = count+1
#01----------------------------------------------------------
#number = None # initialise number with None to leave it empty
#total = 0

#while True :
#    number = int(input('Enter a number (0 to exit): '))

#    if number == 0:
#        break
#    if number == 7:
#        continue
#    total += number # add the entered number to the total

#print('The total is:', total)

#01----------------------------------------------------------
#for num in range(1, 11): # print the numbers 1 to 10
#    print(num)

#for num in range(6): # print the numbers 0 to 5
#    print(num)

#for num in range(5, 51, 3): # print every third number from 5 to 50
#    print(num)

#for num in range(10, 0, -1): # print the numbers 10 to 1
#    print(num) 

#01----------------------------------------------------------
#listVar = ['Huey', 'Dewey', 'Louie']   

# print each item in the list
#for item in listVar:
#    print(item)

#01----------------------------------------------------------
#for i in range(1, 11): 
#    print(i)

#01----------------------------------------------------------
import num
num = random.randint(1,100)
print(num)


#01----------------------------------------------------------
#01----------------------------------------------------------
#01----------------------------------------------------------
#01----------------------------------------------------------


















