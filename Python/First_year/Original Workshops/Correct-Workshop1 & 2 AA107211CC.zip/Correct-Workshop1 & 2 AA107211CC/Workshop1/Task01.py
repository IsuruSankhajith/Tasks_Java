#-------------------------------------------------------------------------
#Task 01
#-------------------------------------------------------------------------
#>>> (1+2)*3
#9
#>>> 

print('Testing')
#= RESTART: C:\Users\USER\Desktop\Original Workshops\Correct-Workshop1 & 2 AA107211CC\Workshop1\Task01.py
#Testing
#>>>

#print('Testing)

#SyntaxError: EOL while scanning string literal
#>>>

#print(Testing)

#Traceback (most recent call last):
#  File "<pyshell#4>", line 1, in <module>
#    print(Testing)
#NameError: name 'Testing' is not defined
#>>>

x = 6
x = x + 1
print(x)
#7
#>>>

value = input('Type Something: ')
print('You typed', value)

#Type Something: j
#You typed j
#>>>

#>>> print('You typed', input('Type Something: '))
#Type Something: d
#You typed d
#>>> 
#-------------------------------------------------------------------------
#-------------------------------------------------------------------------
#-------------------------------------------------------------------------
#-------------------------------------------------------------------------
#-------------------------------------------------------------------------
