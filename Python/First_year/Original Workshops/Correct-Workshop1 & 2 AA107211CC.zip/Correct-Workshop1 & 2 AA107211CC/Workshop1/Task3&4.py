#Task 03------------------------------------------------------------------
#Length------------------------------------------------------------------
centimeter=float(input('Enter centimeter :'))

convert_inches=centimeter * 0.393
print('Inches  :',convert_inches)

meter=float(input('Enter meters :'))

convert_feet=meter * 3.281
print('feet  :',convert_feet)

kilometer=float(input('Enter kilometers :'))
print('kilometer :',kilometer)
convert_miles=kilometer * 0.621
print('miles  :',convert_miles)

#weight------------------------------------------------------------------

gram=float(input('Enter gram :'))
print('gram :',gram)
convert_ounce=gram * 0.035
print('ounce  :',convert_ounce)

kilogram=float(input('kilogram :'))
print('kilogram :',kilogram)
convert_pounds=kilogram * 2.204
print('pounds  :',convert_pounds)

kilogram=float(input('kilogram :'))
print('kilogram :',kilogram)
convert_pounds=kilogram * 2.204
print('pounds  :',convert_pounds)

#volume------------------------------------------------------------------
millilitre=float(input('millilitre :'))
print('millilitre :',millilitre)
convert_fluidounces=millilitre * 0.035
print('fluid ounces  :',convert_fluidounces)

litre=float(input('litres :'))
print('litres :',litre)
convert_quarts=litre * 0.878
print('quarts  :',convert_quarts)

#Task 4------------------------------------------------------------------

Celsius=float(input('Celsius :'))
print('Celsius :',Celsius)
convert_Fahrenheit=Celsius * 9/5+32
print('Fahrenheit  :',convert_Fahrenheit)

#Geomatric------------------------------------------------------------------

#from math import pi

area_of_circle=float(input('Area of circle  :'))
print('Area of circle  :',area_of_circle)
circumference_of_circle=2 * pi **2
print=('circumference of circle  :',circumference_of_circle)

#Nutrition------------------------------------------------------------------
from math import pi

area_of_circle=float(input('Area of circle  :'))
print('Area of circle  :',area_of_circle)
circumference_of_circle=2 * pi **2
print=('circumference of circle  :',circumference_of_circle)

#Nutrition------------------------------------------------------------------

weight=float(input('Weight in Kilograms  :'))
height=float(input('Height in Metres  :'))
x=weight
y=height
print('weight in kilograms  :',weight_in_kilograms)
print('height in metres  :',height_in_metres)

bmi =float(x / (y**4))
print=('Body Mass Index (BMI)  :',bmi)

#finance------------------------------------------------------------------
amount=int(input('amount  :'))
interestRate=int(input('Annual Interest Rate  :'))
years=int(input('Time in Years  :'))

interest =amount*(interestRate / 100)*years
print=(interest)
















