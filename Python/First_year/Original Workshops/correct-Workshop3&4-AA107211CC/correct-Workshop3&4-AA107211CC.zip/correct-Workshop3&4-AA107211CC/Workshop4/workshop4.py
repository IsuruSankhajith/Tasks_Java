#--------------------------------------------------------------------------
#Task 01
#1--------------------------------------------------------------------------
#import random
#print(random.randint(1,20))

#=== RESTART: D:/ACBT/Programming Principles/workshops/workshop4/workshop4.py ===
#4
#>>> 
#2,3,4--------------------------------------------------------------------------
#from random import randint
#import.randint(1,20)
#randint(1,20)
#5--------------------------------------------------------------------------
#import random
#def main():
#    print(random.randint(1,20 ))
#main()
#--------------------------------------------------------------------------
#import random

#def main():
#    names = ['Sam', 'Sue', 'John', 'Mary', 'Toby']
#    choicess(names)
#    sampless(names)

#def choicess(names):
#    find = random.choice(names)
#    print(find)

#def sampless(names):
#    find = random.sample(names,3)
#    print(find)

#main()

#=== RESTART: D:/ACBT/Programming Principles/workshops/workshop4/workshop4.py ===
#Toby
#['Mary', 'Toby', 'Sue']
#>>> 
#10,11,12,13--------------------------------------------------------------------------
#14--------------------------------------------------------------------------
#15--------------------------------------------------------------------------
#--------------------------------------------------------------------------
#--------------------------------------------------------------------------





















